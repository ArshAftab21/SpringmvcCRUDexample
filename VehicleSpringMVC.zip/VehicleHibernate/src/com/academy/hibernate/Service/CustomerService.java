package com.academy.hibernate.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.academy.hibernate.Dao.CustomerDao;
import com.academy.hibernate.Dao.VehicleDao;
import com.academy.hibernate.Model.CustomerPojo;
import com.academy.hibernate.Model.LoginPojo;
import com.academy.hibernate.Model.Vehicle;

@Service
@Qualifier("cs")
public class CustomerService {
	
	@Autowired
	private CustomerDao cusdao;
	@Autowired
	private VehicleDao vehdao;

	public void register(CustomerPojo pojo) 
	{
		cusdao.createDepartment(pojo);
		
	}

	public CustomerPojo login(LoginPojo log) 
	{
		CustomerPojo result=cusdao.login(log.getName(),log.getPassword());
		return result;
	}

	public List<Vehicle> getList() {
		
		List<Vehicle> result=vehdao.getList();
		return result;
	}

	

	public void removeBookedVehicle(int i) 
	{
		
		vehdao.removeVehicle(i);
		
	}

	public List<Vehicle> getCustomerVehiclesList(int user) 
	{
		
		List<Vehicle> list=vehdao.getvehicleList(user);
		return list;
	}

	public void bookVehicle(int id, int user) 
	{
	 
	  vehdao.bookVehicle(id,user);
		
	}

	public int getTotalCost(int user) 
	{
		
		  int price=vehdao.calculateCost(user);
		return price;
	}

	public void registerVehicle(Vehicle v) 
	{
		
		vehdao.createVehicle(v);
		
	}
	
}
