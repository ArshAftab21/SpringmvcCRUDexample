package com.academy.hibernate.Dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.academy.hibernate.Model.CustomerPojo;
import com.academy.hibernate.Model.Vehicle;

@Repository("vehdao")
public class VehicleDao {

	@PersistenceContext
	private EntityManager em;
	
	
	public List<Vehicle> getList() {
		List<Vehicle> list = new ArrayList<>();

		Query query = em.createQuery("from Vehicle where customer_id=null");
		list = (List<Vehicle>) query.getResultList();

		return list;
	}

	public void createVehicle(Vehicle v) {

		em.persist(v);

	}

	public void bookVehicle(int id, int Cus_id) {

		Vehicle v = em.find(Vehicle.class, id);
		CustomerPojo cus = em.getReference(CustomerPojo.class, Cus_id);
		v.setCustomer(cus);

	}

	public List<Vehicle> getvehicleList(int user) {
		List<Vehicle> list = new ArrayList<>();

		Query query = em.createQuery("from Vehicle where customer_id='" + user + "'");
		list = (List<Vehicle>) query.getResultList();

		return list;
	}

	public void removeVehicle(int i) {
		Vehicle v = em.find(Vehicle.class, i);
		v.setCustomer(null);

	}

	public int calculateCost(int user) {
		long price = 0;

		Query query = em.createQuery("select sum(price) from Vehicle where customer_id='" + user + "'");
		price = (long) query.getSingleResult();

		return (int) price;

	}
}
