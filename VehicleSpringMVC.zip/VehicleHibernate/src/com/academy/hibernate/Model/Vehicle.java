package com.academy.hibernate.Model;

import javax.persistence.Cacheable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity

@Table(name="vehicle")
public class Vehicle {
	@Id 
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "vehicle_generators")
	@SequenceGenerator(name="vehicle_generators", sequenceName = "vehicle_seq" , initialValue = 1, allocationSize = 1)
    private int id;
	  private 
	  String vehicle_name;
	  int price;
	  int capacity;
	  int time;
	  
	  @ManyToOne
	    private CustomerPojo customer;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getVehicle_name() {
		return vehicle_name;
	}

	public void setVehicle_name(String vehicle_name) {
		this.vehicle_name = vehicle_name;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public int getCapacity() {
		return capacity;
	}

	public void setCapacity(int capacity) {
		this.capacity = capacity;
	}

	public int getTime() {
		return time;
	}

	public void setTime(int time) {
		this.time = time;
	}

	public CustomerPojo getCustomer() {
		return customer;
	}

	public void setCustomer(CustomerPojo customer) {
		this.customer = customer;
	}

	public Vehicle(String vehicle_name, int price, int capacity,
			int time, CustomerPojo customer) 
	{
		super();
		this.vehicle_name = vehicle_name;
		this.price = price;
		this.capacity = capacity;
		this.time = time;
		this.customer = customer;
	}

	public Vehicle() 
	{
		super();
	}
	  
	  

}
