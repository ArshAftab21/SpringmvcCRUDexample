package com.academy.hibernate.Service;

import java.util.List;








import com.academy.hibernate.Dao.CustomerDao;
import com.academy.hibernate.Dao.VehicleDao;
import com.academy.hibernate.Model.CustomerPojo;
import com.academy.hibernate.Model.LoginPojo;
import com.academy.hibernate.Model.Vehicle;

public class CustomerService {

	public void register(CustomerPojo pojo) 
	{
		CustomerDao dao=new CustomerDao();
		dao.createDepartment(pojo);
		
	}

	public CustomerPojo login(LoginPojo log) 
	{
		CustomerDao dao=new CustomerDao();
		CustomerPojo result=dao.login(log.getName(),log.getPassword());
		return result;
	}

	public List<Vehicle> getList() {
		VehicleDao dao=new VehicleDao();
		List<Vehicle> result=dao.getList();
		return result;
	}

	

	public void removeBookedVehicle(int i) 
	{
		VehicleDao dao=new VehicleDao();
		dao.removeVehicle(i);
		
	}

	public List<Vehicle> getCustomerVehiclesList(int user) 
	{
		VehicleDao dao=new VehicleDao();
		List<Vehicle> list=dao.getvehicleList(user);
		return list;
	}

	public void bookVehicle(int id, int user) 
	{
	  VehicleDao dao=new VehicleDao();
	  dao.bookVehicle(id,user);
		
	}

	public int getTotalCost(int user) 
	{
		VehicleDao dao=new VehicleDao();
		  int price=dao.calculateCost(user);
		return price;
	}

	public void registerVehicle(Vehicle v) 
	{
		VehicleDao dao=new VehicleDao();
		dao.createVehicle(v);
		
	}
	
}
