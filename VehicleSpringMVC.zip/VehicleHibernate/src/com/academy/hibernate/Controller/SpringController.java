package com.academy.hibernate.Controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.academy.hibernate.Model.Checkboxpojo;
import com.academy.hibernate.Model.CustomerPojo;
import com.academy.hibernate.Model.LoginPojo;
import com.academy.hibernate.Model.Vehicle;
import com.academy.hibernate.Service.CustomerService;

@Controller
public class SpringController {
	
	@Autowired
	private CustomerService cs;
	
	@RequestMapping("/openadminform")
	public ModelAndView vehicleform() {
		return new ModelAndView("Vehicleregister", "command", new Vehicle());
	}

	@RequestMapping("/openregistrationform")
	public ModelAndView customeregistration() {
		return new ModelAndView("register", "command", new CustomerPojo());
	}

	@RequestMapping("/loginform")
	public ModelAndView openloginform() {
		return new ModelAndView("login", "command", new LoginPojo());
	}

	@RequestMapping("/openhome")
	public ModelAndView openHomepage(Model model) {
		List<Vehicle> vlist = cs.getList();
		model.addAttribute("vlist", vlist);
		return new ModelAndView("home", "command", new Checkboxpojo());
	}

	@RequestMapping("/openbookedvehicle")
	public ModelAndView openBookedVehiclePage(Model model, HttpServletRequest request, HttpServletResponse response) {
		HttpSession session = request.getSession();
		int user = (Integer) session.getAttribute("userid");
		String username = (String) session.getAttribute("username");
		model.addAttribute("user", username);
		List<Vehicle> clist = cs.getCustomerVehiclesList(user);
		model.addAttribute("cvlist", clist);
		return new ModelAndView("customerbooked", "command", new Checkboxpojo());

	}

	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public ModelAndView registerVehicle(@ModelAttribute("vehicle") Vehicle vehicle) {
		
		cs.registerVehicle(vehicle);
		return new ModelAndView("redirect:/openadminform");
	}

	@RequestMapping(value = "/registerCustomer", method = RequestMethod.POST)
	public ModelAndView registerCus(@ModelAttribute("cus") CustomerPojo cus) {
		
		cs.register(cus);
		return new ModelAndView("redirect:/loginform");
	}

	@RequestMapping(value = "/LoginValid", method = RequestMethod.POST)
	public ModelAndView loginUser(HttpServletRequest request, HttpServletResponse response,
			@ModelAttribute("log") LoginPojo log) {
		CustomerPojo b = cs.login(log);
		if (b != null) {
			HttpSession session = request.getSession();
			session.setAttribute("userid", b.getId());
			session.setAttribute("username", b.getName());
			System.out.println("Logged-in");
			return new ModelAndView("redirect:/openhome");
		} else {
			return new ModelAndView("redirect:/loginform");
		}
	}

	@RequestMapping(value = "/vehiclebooking", method = RequestMethod.POST)
	public ModelAndView bookVehicle(@ModelAttribute("chk") Checkboxpojo chk, HttpServletRequest request,
			HttpServletResponse response, Model model) {
		HttpSession session = request.getSession();
		int cus_id = (Integer) session.getAttribute("userid");
		System.out.println(cus_id);
		String username = (String) session.getAttribute("username");
		for (String s : chk.getVehiclebook()) {
			int id = Integer.parseInt(s);
			System.out.println("Vehicleid" + id);
			cs.bookVehicle(id, cus_id);
		}
		model.addAttribute("user", username);
		List<Vehicle> clist = cs.getCustomerVehiclesList(cus_id);
		model.addAttribute("cvlist", clist);
		return new ModelAndView("customerbooked", "command", new Checkboxpojo());
	}

	@RequestMapping(value = "/remove", method = RequestMethod.POST)
	public ModelAndView removebooking(@ModelAttribute("chk") Checkboxpojo chk, HttpServletRequest request,
			HttpServletResponse response, Model model) {
		for (String s : chk.getVehiclebook()) {
			int i = Integer.parseInt(s);
			cs.removeBookedVehicle(i);
		}

		HttpSession session = request.getSession();
		int user = (Integer) session.getAttribute("userid");
		model.addAttribute("user", user);
		List<Vehicle> clist = cs.getCustomerVehiclesList(user);
		model.addAttribute("cvlist", clist);
		return new ModelAndView("redirect:/openbookedvehicle");
	}
	
	@RequestMapping(value = "/checkout")
	public ModelAndView checkout(@ModelAttribute("chk") Checkboxpojo chk, HttpServletRequest request,
			HttpServletResponse response, Model model) {
		
		HttpSession session=request.getSession();
		int userid=(Integer)session.getAttribute("userid");
		String user=(String)session.getAttribute("username");
		int price=cs.getTotalCost(userid);
		model.addAttribute("user",user);
		model.addAttribute("price",price);
		return new ModelAndView("checkout");
	}

	@RequestMapping("/logout")
	public ModelAndView logout( HttpServletRequest request) {
		HttpSession session=request.getSession();
		session.invalidate();
		return new ModelAndView("redirect:/");
	}
}
