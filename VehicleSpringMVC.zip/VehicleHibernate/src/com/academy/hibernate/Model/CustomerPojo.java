package com.academy.hibernate.Model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Cacheable;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;



@Entity

@Table(name="Customer")
public class CustomerPojo {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "dept_generatorss")
	@SequenceGenerator(name="dept_generatorss", sequenceName = "dept_seqqq" , initialValue = 1, allocationSize = 1)
	private int id;
	private
    String name;
    String email;
    String password;
    String Contact;
    String Date;
    
    @OneToMany(mappedBy = "customer", cascade = CascadeType.ALL,fetch = FetchType.EAGER)
	private List<Vehicle> listProfessor = new ArrayList<Vehicle>();
    
	public List<Vehicle> getListProfessor() {
		return listProfessor;
	}
	public void setListProfessor(List<Vehicle> listProfessor) {
		this.listProfessor = listProfessor;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getContact() {
		return Contact;
	}
	public void setContact(String contact) {
		Contact = contact;
	}
	public String getDate() {
		return Date;
	}
	public void setDate(String date) {
		Date = date;
	}
	public CustomerPojo() {
		super();
	}
	
}
