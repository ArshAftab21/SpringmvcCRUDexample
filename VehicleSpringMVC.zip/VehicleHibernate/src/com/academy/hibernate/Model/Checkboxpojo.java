package com.academy.hibernate.Model;

public class Checkboxpojo 
{
  private String[] vehiclebook;

public String[] getVehiclebook() {
	return vehiclebook;
}

public void setVehiclebook(String[] vehiclebook) {
	this.vehiclebook = vehiclebook;
}
  
}
