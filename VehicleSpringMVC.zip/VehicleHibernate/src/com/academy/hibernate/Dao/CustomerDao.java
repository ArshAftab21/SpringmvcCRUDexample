package com.academy.hibernate.Dao;

import java.util.List;

import javax.persistence.Query;

import com.academy.hibernate.Model.CustomerPojo;
import com.academy.hibernate.Utils.AppBaseDao;



public class CustomerDao extends AppBaseDao 
{
	public void createDepartment(CustomerPojo customer) {
		try {
			em = getEntityManager();
			em.getTransaction().begin();
			em.persist(customer);
			em.getTransaction().commit();
			

		} catch (Exception e) {
			e.printStackTrace();
		} 
		finally {
			closeEntityManager();
		}
	}

	public CustomerPojo login(String username, String password) 
	{
		CustomerPojo cus=null;
		try {
			em = getEntityManager();
			em.getTransaction().begin();
			Query query = em.createQuery("from CustomerPojo where name='"+username+"' and password='"+password+"'");
			cus= (CustomerPojo)query.getSingleResult();
			em.getTransaction().commit();

		} catch (Exception e) {
			e.printStackTrace();
		} 
		finally {
			closeEntityManager();
		}
		return cus;
	}
	
	
}
