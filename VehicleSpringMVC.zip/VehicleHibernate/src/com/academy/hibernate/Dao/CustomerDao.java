package com.academy.hibernate.Dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.academy.hibernate.Model.CustomerPojo;

@Repository("cusdao")
public class CustomerDao {
	
	@PersistenceContext
	private EntityManager em;

	public void createDepartment(CustomerPojo customer) {

		em.persist(customer);

	}

	public CustomerPojo login(String username, String password) {
		CustomerPojo cus = null;

		Query query = em.createQuery("from CustomerPojo where name='" + username + "' and password='" + password + "'");
		cus = (CustomerPojo) query.getSingleResult();
		return cus;
	}

}
