package com.academy.hibernate.Dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Query;

import com.academy.hibernate.Model.CustomerPojo;
import com.academy.hibernate.Model.Vehicle;
import com.academy.hibernate.Utils.AppBaseDao;

public class VehicleDao extends AppBaseDao
{

	public List<Vehicle> getList() 
	{
	List<Vehicle> list=new ArrayList<>();
	
		try 
		{
			em = getEntityManager();
			em.getTransaction().begin();
			Query query = em.createQuery("from Vehicle where customer_id=null");
			list= (List<Vehicle>)query.getResultList();
			em.getTransaction().commit();

		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		} 
		finally 
		{
			closeEntityManager();
		}
		return list;
    }

	public void createVehicle(Vehicle v) 
	{
		try {
			em = getEntityManager();
			em.getTransaction().begin();
			em.persist(v);
			em.getTransaction().commit();
			

		} catch (Exception e) {
			e.printStackTrace();
		} 
		finally {
			closeEntityManager();
		}
		
	}

	public void bookVehicle(int id, int Cus_id) 
	{
		try
		{
			em = getEntityManager();
			em.getTransaction().begin();
			Vehicle v=em.find(Vehicle.class,id);
			CustomerPojo cus=em.getReference(CustomerPojo.class,Cus_id);
			v.setCustomer(cus);
			em.getTransaction().commit();
			
		}
		catch (Exception e) {
			e.printStackTrace();
		} 
		finally {
			closeEntityManager();
		}
	}

	public List<Vehicle> getvehicleList(int user) 
	{
		List<Vehicle> list=new ArrayList<>();
		
		try 
		{
			em = getEntityManager();
			em.getTransaction().begin();
			Query query = em.createQuery("from Vehicle where customer_id='"+user+"'");
			list= (List<Vehicle>)query.getResultList();
			em.getTransaction().commit();

		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		} 
		finally 
		{
			closeEntityManager();
		}
		
		return list;
	}

	public void removeVehicle(int i) 
	{
		try
		{
			em = getEntityManager();
			em.getTransaction().begin();
			Vehicle v=em.find(Vehicle.class,i);
			v.setCustomer(null);
			em.getTransaction().commit();
			
		}
		catch (Exception e) {
			e.printStackTrace();
		} 
		finally 
		{
			closeEntityManager();
		}
		
	}

	public int calculateCost(int user) 
	{
		long price=0;
		try 
		{
			em = getEntityManager();
			em.getTransaction().begin();
			Query query = em.createQuery("select sum(price) from Vehicle where customer_id='"+user+"'");
			price= (long) query.getSingleResult();
			em.getTransaction().commit();

		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		} 
		finally 
		{
			closeEntityManager();
		}
		return (int)price;
		
	}
}
